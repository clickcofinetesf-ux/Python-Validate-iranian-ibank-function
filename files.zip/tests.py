from django.core.exceptions import ValidationError
from django.test import SimpleTestCase

from .validators import check_sheba, validate_sheba

VALID = "IR210170000000012345678901"  # synthetic: valid checksum, not a real account


class ShebaTests(SimpleTestCase):
    def test_valid(self):
        r = check_sheba(VALID)
        self.assertTrue(r["valid"])
        self.assertEqual(r["bank"]["name"], "Melli")

    def test_normalization(self):
        self.assertTrue(check_sheba("ir21 0170 0000 0001 2345 6789 01")["valid"])
        self.assertTrue(check_sheba("IR21-0170-0000-0001-2345-6789-01")["valid"])
        self.assertTrue(check_sheba("IR۲۱۰۱۷۰۰۰۰۰۰۰۰۱۲۳۴۵۶۷۸۹۰۱")["valid"])

    def test_errors(self):
        self.assertEqual(check_sheba(VALID[:-1] + "2")["error"], "invalid_checksum")
        self.assertEqual(check_sheba(VALID[:-2])["error"], "invalid_length")
        self.assertEqual(check_sheba(VALID[:10] + "AB" + VALID[12:])["error"], "invalid_format")
        self.assertEqual(check_sheba(12345)["error"], "not_a_string")

    def test_raises(self):
        validate_sheba(VALID)
        with self.assertRaises(ValidationError) as cm:
            validate_sheba("IR000")
        self.assertEqual(cm.exception.code, "invalid_length")
