"""
Iranian Sheba (IBAN) validation for Django.

Usage:
    from iran_sheba.validators import validate_sheba, ShebaValidator
"""
import json
import re
from functools import lru_cache
from pathlib import Path

from django.core.exceptions import ValidationError
from django.utils.deconstruct import deconstructible

CONFIG_PATH = Path(__file__).resolve().parent / "sheba.json"

ERROR_MESSAGES = {
    "not_a_string": "شماره شبا باید به صورت متن وارد شود.",
    "invalid_length": "شماره شبا باید ۲۶ کاراکتر (IR و ۲۴ رقم) باشد.",
    "invalid_format": "قالب شماره شبا نامعتبر است. شبا باید با IR شروع شود و ادامه آن ۲۴ رقم باشد.",
    "invalid_checksum": "شماره شبا نامعتبر است (رقم کنترل اشتباه است).",
    "unknown_bank_code": "کد بانک در شماره شبا شناخته‌شده نیست.",
    "bank_regex_mismatch": "قالب شماره شبا با بانک مربوطه همخوانی ندارد.",
    "legacy_bank_not_allowed": "این بانک دیگر پشتیبانی نمی‌شود.",
}

_PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


@lru_cache(maxsize=1)
def load_config():
    with open(CONFIG_PATH, encoding="utf-8") as f:
        return json.load(f)


def normalize_sheba(value):
    """Strip spaces/dashes, convert Persian/Arabic digits, uppercase."""
    s = value.translate(_PERSIAN_DIGITS)
    return re.sub(r"[\s\-\u200c\u200f\u200e]", "", s).upper()


def check_sheba(value, *, require_known_bank=True, allow_legacy=True):
    """Return {"valid", "error", "sheba", "bank"} without raising."""
    config = load_config()

    def result(valid, error=None, sheba=None, bank=None):
        return {"valid": valid, "error": error, "sheba": sheba, "bank": bank}

    if not isinstance(value, str):
        return result(False, "not_a_string")

    s = normalize_sheba(value)

    if len(s) != config["length"]:
        return result(False, "invalid_length")
    if not re.fullmatch(config["generic"]["regex"], s):
        return result(False, "invalid_format")

    suffix = config["checksum"]["rearranged_suffix"]
    if int(s[4:] + suffix + s[2:4]) % 97 != 1:
        return result(False, "invalid_checksum")

    code = s[4:7]
    bank = next((b for b in config["banks"] if b["code"] == code), None)

    if bank is None:
        if require_known_bank:
            return result(False, "unknown_bank_code", s)
        return result(True, None, s, None)
    if not re.fullmatch(bank["regex"], s):
        return result(False, "bank_regex_mismatch", s, bank)
    if bank.get("legacy") and not allow_legacy:
        return result(False, "legacy_bank_not_allowed", s, bank)

    return result(True, None, s, {"code": bank["code"], "name": bank["name"]})


def validate_sheba(value, **options):
    """Django-style validator: raises ValidationError, returns None if valid."""
    r = check_sheba(value, **options)
    if not r["valid"]:
        raise ValidationError(ERROR_MESSAGES[r["error"]], code=r["error"])


@deconstructible
class ShebaValidator:
    """Validator class usable in model fields / serializers (migration-safe)."""

    def __init__(self, require_known_bank=True, allow_legacy=True):
        self.require_known_bank = require_known_bank
        self.allow_legacy = allow_legacy

    def __call__(self, value):
        validate_sheba(
            value,
            require_known_bank=self.require_known_bank,
            allow_legacy=self.allow_legacy,
        )

    def __eq__(self, other):
        return (
            isinstance(other, ShebaValidator)
            and self.require_known_bank == other.require_known_bank
            and self.allow_legacy == other.allow_legacy
        )
