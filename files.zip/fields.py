from django.db import models

from .validators import ShebaValidator, normalize_sheba


class ShebaField(models.CharField):
    """
    CharField that validates a Sheba and always stores it normalized
    (e.g. "ir21 0170 ..." -> "IR210170...").
    """

    def __init__(self, *args, require_known_bank=True, allow_legacy=True, **kwargs):
        self.require_known_bank = require_known_bank
        self.allow_legacy = allow_legacy
        kwargs.setdefault("max_length", 26)
        super().__init__(*args, **kwargs)
        self.validators.append(
            ShebaValidator(require_known_bank=require_known_bank, allow_legacy=allow_legacy)
        )

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if kwargs.get("max_length") == 26:
            del kwargs["max_length"]
        if self.require_known_bank is not True:
            kwargs["require_known_bank"] = self.require_known_bank
        if self.allow_legacy is not True:
            kwargs["allow_legacy"] = self.allow_legacy
        return name, path, args, kwargs

    def to_python(self, value):
        value = super().to_python(value)
        return normalize_sheba(value) if isinstance(value, str) else value

    def get_prep_value(self, value):
        value = super().get_prep_value(value)
        return normalize_sheba(value) if isinstance(value, str) else value
